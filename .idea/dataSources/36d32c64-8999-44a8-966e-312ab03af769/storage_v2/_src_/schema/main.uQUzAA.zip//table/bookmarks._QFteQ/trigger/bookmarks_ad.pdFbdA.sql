CREATE TRIGGER bookmarks_ad AFTER DELETE ON bookmarks
    BEGIN
        INSERT INTO bookmarks_fts (bookmarks_fts, rowid, URL, metadata, "desc")
        VALUES ('delete', old.id, old.URL, old.metadata, old.desc);
    END;

