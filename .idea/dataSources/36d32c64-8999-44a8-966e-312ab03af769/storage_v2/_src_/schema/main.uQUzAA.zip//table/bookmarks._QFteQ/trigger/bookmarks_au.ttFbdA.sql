CREATE TRIGGER bookmarks_au AFTER UPDATE ON bookmarks
    BEGIN
        INSERT INTO bookmarks_fts (bookmarks_fts, rowid, URL, metadata, "desc")
        VALUES ('delete', old.id, old.URL, old.metadata, old.desc);
        INSERT INTO bookmarks_fts (rowid, URL, metadata, "desc")
        VALUES (new.id, new.URL, new.metadata, new.desc);
    END;

