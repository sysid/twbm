CREATE TRIGGER [UpdateLastTime]
    AFTER
    UPDATE
    ON bookmarks2
    FOR EACH ROW
    WHEN NEW.last_update_ts <= OLD.last_update_ts
BEGIN
    update bookmarks2 set last_update_ts=CURRENT_TIMESTAMP where id=OLD.id;
END;

