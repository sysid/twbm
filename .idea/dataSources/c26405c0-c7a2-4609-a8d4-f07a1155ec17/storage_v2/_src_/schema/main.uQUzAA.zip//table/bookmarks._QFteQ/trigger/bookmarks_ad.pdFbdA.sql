CREATE TRIGGER bookmarks_ad AFTER DELETE ON bookmarks
    BEGIN
        INSERT INTO bookmarks_fts (bookmarks_fts, rowid, URL, metadata, tags, "desc")
        VALUES ('delete', old.id, old.URL, old.metadata, old.tags, old.desc);
    END;

