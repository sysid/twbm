CREATE TRIGGER bookmarks_ai AFTER INSERT ON bookmarks
    BEGIN
        INSERT INTO bookmarks_fts (rowid, URL, metadata, "desc")
        VALUES (new.id, new.URL, new.metadata, new.desc);
    END;

