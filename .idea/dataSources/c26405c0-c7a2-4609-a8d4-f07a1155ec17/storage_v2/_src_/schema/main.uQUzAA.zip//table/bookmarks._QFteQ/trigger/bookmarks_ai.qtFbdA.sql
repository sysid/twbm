CREATE TRIGGER bookmarks_ai AFTER INSERT ON bookmarks
    BEGIN
        INSERT INTO bookmarks_fts (rowid, URL, metadata, tags, "desc")
        VALUES (new.id, new.URL, new.metadata, new.tags, new.desc);
    END;

